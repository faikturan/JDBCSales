package com.faikturan.service.impl;

import java.util.List;

import com.faikturan.model.OrderDetail;
import com.faikturan.model.Orders;
import com.faikturan.service.OrderDetailService;

public class OrderDetailServiceImpl implements OrderDetailService {

	@Override
	public List<OrderDetail> findDetailbyOrderId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean addDetailsInOrder(Orders order, List<OrderDetail> orderDetailList) {
		// TODO Auto-generated method stub
		return false;
	}

}
